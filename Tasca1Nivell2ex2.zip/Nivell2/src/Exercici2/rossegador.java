package Exercici2;

public class rossegador { // no hi ha propietats
	
	public rossegador() { // m�tode constructor, no es pot donar valor inicial a les propietats

	}
public String menja(){ // GETTER
	return " El rossegador menja" ;
}
public String salta(){ // GETTER
	return " el rossegador salta" ;
	}
}