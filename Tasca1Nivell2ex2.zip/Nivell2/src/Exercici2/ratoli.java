package Exercici2;

public class ratoli extends rossegador {

	public String menja(){
		
		return " El ratol� menja" ;
	}
	public String salta(){
		return " el ratol� salta" ;
		}
	
}
