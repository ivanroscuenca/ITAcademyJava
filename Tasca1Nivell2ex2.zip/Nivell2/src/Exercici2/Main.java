package Exercici2;

/*Creu una jerarquia d'her�ncia Roedor: Raton, Jerbo, Hamster. 
En la casi base proporcioni els m�todes que s�n comuns als rosegadors, 
i substitueixi aquests m�todes en les classes derivades per a obtenir diferents
comportaments depenent del tipus espec�fic de rosegador. Creu una matriu d'objectes Rosegador,
empleni-la amb diferents tipus espec�fics de rosegadors 
i invoqui els m�todes de la classe base demostrant qu� succeeix.*/

public class Main {

	public static void main(String[] args) {
		
		//rossegador num1 = new rossegador(); // instanciar classe rossegador
		
		ratoli num2 = new ratoli(); // instanciar classe rossegador
		
		jerbo num3 = new jerbo(); //instanciar classe jerbo
		
		hamster num4 = new hamster(); //instanciar classe hamster
		
		
		rossegador [] rossegadors = new rossegador [4] ; // matriu d'objectes Rossegadors
		
		rossegadors [0] = new rossegador();
		
		rossegadors [1] = num2; // Polimorfisme
		
		rossegadors [2] = num3; // Polimorfisme
		
		rossegadors [3] = num4; // Polimorfisme

		for (rossegador r : rossegadors){ // invocar m�todes amb for millorat
			System.out.println(r.menja() + " i" + r.salta());
		}
	}

}
