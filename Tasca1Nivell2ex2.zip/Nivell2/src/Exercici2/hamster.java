package Exercici2;

public class hamster extends rossegador {

public String menja(){
		
		return " El hamster menja" ;
	}
	public String salta(){
		return " el hamster salta" ;
		}
}
