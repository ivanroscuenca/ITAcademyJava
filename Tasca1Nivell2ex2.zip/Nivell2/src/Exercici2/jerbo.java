package Exercici2;

public class jerbo extends rossegador{

public String menja(){
		
		return " El jerbo menja" ;
	}
	public String salta(){
		return " el jerbo salta" ;
		}
	
}
