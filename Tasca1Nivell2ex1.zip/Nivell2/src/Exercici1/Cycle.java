package Exercici1;

/*Nivell 2
Creu una classe Cycle, amb subclasses Unicycle, Bicycle i Tricycle.
Demostri que es pot generalitzar una inst�ncia de cada tipus a Cycle mitjan�ant un m�tode 'ride()'.
Afegeixi un m�tode 'wheels()' a Cycle, que retorni el nombre de rodes. Modifiqui 'ride()' per a invocar 'wheels()'
i verifiqui que funciona el polimorfisme.
Afegeixi un m�tode 'balance()' a Unicycle i a Bicycle, per� no a Tricycle. Creu inst�ncies de tres tipus i generalitzi-les per a formar una matriu d'objectes Cycle. Tracti d'invocar 'balance()' en cada element de la matriu.
Realitzi una especialitzaci� i invoqui 'balance()' demostrant el que ocorre. */
public abstract class Cycle {
	
	
public Cycle(){	
	}

public static void main(String[] args) {

	Unicycle bike1 = new Unicycle();
	Bicycle bike2 = new Bicycle();
	Tricycle bike3 = new Tricycle();
	
	ride(bike1);
	ride(bike2);
	ride(bike3);
	
}

public int wheels(Cycle bike){
	
	if (bike.toString().equals("Unicycle")) return 1 ;
	if (bike.toString().equals("Bicycle")) return 2;
	else if (bike.toString().equals("Tricycle")) return 3;
	else return 0;
}

	public static void ride(Cycle bike){
		System.out.println("Riding a " + bike.toString() + " needs only " + 
	bike.wheels(bike) + " wheel(s)" + bike.balance() );

	}
	
	public String balance(){ // GETTER
		return "" ;
	}

}
