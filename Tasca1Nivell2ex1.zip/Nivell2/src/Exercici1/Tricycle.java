package Exercici1;

public class Tricycle extends Cycle{
	public String toString(){
		return "Tricycle";	
	}
}
