package Exercici1;

public class Unicycle extends Cycle{
	public String toString(){
		return "Unicycle";
	}
	
 public String balance(){ // GETTER
		return " Need balance to drive" ;
	}
}
