package Exercici1;

public class Bicycle extends Cycle{
	public String toString(){
		return "Bicycle";
	}
	
	public String balance(){ // GETTER
		return " Need balance to drive" ;
	}
	
}
