package exercici6;

public class frog extends amphibian{
 
	public frog() {
		super();
	}
	
	public String getCroack() {
	    return  "The frog makes croak " ;
	  }
	
	
}
