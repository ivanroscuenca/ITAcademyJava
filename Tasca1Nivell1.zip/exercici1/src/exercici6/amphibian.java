package exercici6;

/*Crea una classe denominada Amphibian. A partir d'aquesta, defineixi una nova classe denominada Frog que hereti de l'anterior. 
Inclogui una s�rie de m�todes apropiats en la classe basi. 
En 'main()' creu un objecte Frog i relice una generalitzaci� a Amphibian, demostrant que tots els m�todes continuen funcionant.*/

public class amphibian {
	int legs;
	
	public amphibian() {
	}
	
	public String getPotes(int potes) {
	    return  "L'anfibi t� " + potes  + " potes";
	  }

}
