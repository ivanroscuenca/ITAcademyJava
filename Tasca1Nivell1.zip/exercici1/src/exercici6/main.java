package exercici6;

public class main {

	public main(String[] args) {
		amphibian num1 = new amphibian();
		frog num2 = new frog();
		
		System.out.println(num1.getPotes(4));
		
		System.out.println(num2.getPotes(4));
		System.out.println(num2.getCroack());
	}
	
}