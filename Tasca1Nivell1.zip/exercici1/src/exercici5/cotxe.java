package exercici5;

public class cotxe extends vehicle {
	
	String marca;
	int ruedas;
	String modelo;
	int cv;

public cotxe(String marca,String modelo,int ruedas, String color,int cv) {
	super(marca, ruedas, modelo);
	this.ruedas = ruedas;
    this.marca=marca;
    this.modelo=modelo;
    this.color=color;
	this.cv=cv;
    
	}

public String getName(String marca,String modelo, int ruedas, String color,int cv) {
    return  "La marca es " + marca + " modelo es " + modelo+ " y tiene : " + ruedas + " ruedas y de color " + color + " " + cv + " CV" ;
  }

}

