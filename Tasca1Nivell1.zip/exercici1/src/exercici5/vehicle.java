package exercici5;

/* Exercici 5  Crea una classe amb un m�tode que estigui sobrecarregat tres vegades. 
 * Defineixi una nova classe que hereti de l'anterior i afegeixi una nova versi� sobrecarregada del m�tode.
 * Mostri que els quatre m�todes estan disponibles en la classe derivada.
 */

public class vehicle {
		
	int ruedas;
	String marca;
	String modelo;
	String color;
	
	public vehicle(String marca,int ruedas) {
	    this.ruedas = ruedas;
	    this.marca=marca;
	}
	
	public vehicle(String marca, int ruedas,String modelo) {
	    this.ruedas = ruedas;
	    this.marca=marca;
	    this.modelo=modelo;
	}
	
	public vehicle(String marca,int ruedas,String modelo, String color) {
	    this.ruedas = ruedas;
	    this.marca=marca;
	    this.modelo=modelo;
	    this.color=color;
	    
	}
	
	public static void main(String[] args) {
		vehicle car1 = new vehicle("Seat",4);
		
		cotxe cotxe1 = new cotxe ("Seat", "Ibiza", 4, "Blanco", 150);
		
		System.out.println(car1.getName("Seat",4));
		
		System.out.println(car1.getName("Seat", "Leon", 4));
		
		System.out.println(car1.getName("Seat","Leon", 4, "blanco"));
		
		System.out.println(cotxe1.getName("Seat","Ibiza", 4));
		
		}

	public String getName(String marca, int ruedas) {
	    return  "La marca es " + marca + " y tiene : " + ruedas + " ruedas";
	  }

	public String getName(String marca,String modelo, int ruedas) {
	    return  "La marca es " + marca + " modelo es " + modelo+ " y tiene : " + ruedas + " ruedas";
	  }
	
	public String getName(String marca,String modelo, int ruedas, String color) {
	    return  "La marca es " + marca + " modelo es " + modelo+ " y tiene : " + ruedas + " ruedas y de color " + color ;
	  }
	
	
	
	}
	

	
	

