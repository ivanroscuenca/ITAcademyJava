package exercici4;

/* Exercici 4 Crea una classe amb un camp static final i un camp final. 
 * Demostri la difer�ncia entre els dos.
 */

public class vehicle {
		
	final int ruedas;
	String marca;
	String modelo;
	String color;
	static final int cv=150;
	
	public vehicle(int ruedas,String marca, String modelo,String color,int cv) {
		this.ruedas=ruedas;
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
	}
	
	public static void main(String[] args) {
		vehicle car1 = new vehicle(4,"Seat", "Leon", "Blanco", 150);
		
		System.out.println(car1.ruedas);
		System.out.println(vehicle.cv);
		
	}
	
}

