package exercici7;

public class frog extends amphibian{
  int eyes;
  
	public frog() {
		super();
	}
	
	public String getInfo(int potes, int eyes) {
	    return  "the frog has " + potes  + " legs" + " and " +  eyes + " eyes." ;
	  }

	
	public String getCroack() {
	    return  "The frog makes croak " ;
	  }
	
}
