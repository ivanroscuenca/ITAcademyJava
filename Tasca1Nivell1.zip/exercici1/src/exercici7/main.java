package exercici7;

public class main {

	public main(String[] args) {
		amphibian num1 = new amphibian();
		frog num2 = new frog();
		
		System.out.println(num1.getInfo(4));
		// System.out.println(num1.getCroack()); no pot
		
		System.out.println(num2.getInfo(4, 2));
		System.out.println(num2.getCroack());

	}
}
