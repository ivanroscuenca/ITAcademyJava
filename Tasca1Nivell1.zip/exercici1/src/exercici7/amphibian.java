package exercici7;

/*Modifiqui l'exercici anterior perqu� l'objecte Frog substitueixi les definicions de m�todes de la classe basi
 *(proporcioni noves definicions utilitzant les mateixes signatures de m�todes). Demostri el que ocorre en 'main()'.
 */

public class amphibian {
	int legs;
	
	public amphibian() {
		
	}
	
	public String getInfo(int potes) {
	    return  "L'anfibi t� " + potes  + " potes";
	  }

}
