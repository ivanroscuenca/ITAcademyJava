package exercici1;

/*Exercici 1. Al package exercici1, crea una classe Vehicle amb 3 m�todes:
 *  un constructor, un main i el m�tode iniciar, que es invocat pel 'main()'.
 *  Demostri la seq��ncia d'execuci� dels m�todes de la classe.*/

public class vehicle {
	
	int ruedas;
	String marca;
	String modelo;
	String color;
	int cv;
	
	public vehicle(int ruedas,String marca, String modelo,String color,int cv) {
		this.ruedas=ruedas;
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
		this.cv=cv;
	}
	
	public static void main(String[] args) {
		vehicle car1 = new vehicle(4,"Seat", "Leon", "Blanco", 150);
		
		System.out.println("Mi coche tiene " + car1.ruedas + " ruedas , es un "
		+ car1.marca + " " + car1.modelo + " " + car1.color + " " + car1.cv + " CV.");
				
		Iniciar();
	}
	
	static void Iniciar() {
	    System.out.println("Rum , Rum !");
	  }
}
