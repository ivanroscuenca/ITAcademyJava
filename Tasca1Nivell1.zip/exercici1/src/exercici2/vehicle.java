package exercici2;

/* Exercici 2. Al package exercici2, crea una classe Vehicle amb dos m�todes: 
 * un static (a part del main) de nom parar i un altre no de nom iniciar.
 * Demostri com invocar el m�tode static i el no-static des del main.
 */

public class vehicle {
		
	int ruedas;
	String marca;
	String modelo;
	String color;
	int cv;
	
	public vehicle(int ruedas,String marca, String modelo,String color,int cv) {
		this.ruedas=ruedas;
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
		this.cv=cv;
	}
	
	public static void main(String[] args) {
		vehicle car1 = new vehicle(4,"Seat", "Leon", "Blanco", 150);
		
		car1.Iniciar();
		Parar();
	}
	
	public void Iniciar() { // m�tode no static
	    System.out.println("Rum , Rum !");
	  }
	
	 static void Parar() { // m�tode static
		    System.out.println("Stop! ");
		  }
	
}

