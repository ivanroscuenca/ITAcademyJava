package exercici3;

/* Exercici 3.  Al package exercici3, demostri que el proc�s de c�rrega d'una classe nom�s t� lloc una vegada. 
 * Demostri que la c�rrega pot ser provocada per la creaci� de la primera inst�ncia d'aquesta classe o per l'acc�s 
 * a un membre est�tic d'aquesta.
 */

public class vehicle {
	
	public vehicle() {
	
	}
	
	public static void main(String[] args) {
		vehicle car1 = new vehicle();
		
		car1.Iniciar();
		Parar();
	}
	
	public void Iniciar() { // m�tode no static
	    System.out.println("Rum , Rum !");
	  }
	
	 static void Parar() { // m�tode static
		    System.out.println("Stop! ");
		  }
	
}

