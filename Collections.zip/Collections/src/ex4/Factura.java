package ex4;

import java.util.*;




public class Factura implements Comparable<Factura> {
	
	private int number;
	private String name;


	
public Factura(int number, String name) {
		this.number = number;
		this.name = name;
	}


public int compareTo(Factura f) {

	if (this.number<f.number)
	return -1;
	if (this.number==f.number)
	return 0;
	return 1;
	
			
	
}

	public String toString() {
		return "Invoice number: " +number + ", Name: "+ name;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(number);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Factura other = (Factura) obj;
		return number == other.number;
	}
	
	
}
