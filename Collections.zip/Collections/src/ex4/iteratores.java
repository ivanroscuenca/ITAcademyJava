package ex4;

import java.util.*;



/*Escriba un ḿetodo que utilitzi un iterador per a recórrer una col·lecció i imprimeixi 
el resultat de toString() per a cada objecte del Contenidor.
Empleni tots els diferents tipus de Java Collections amb una sèrie d'objectes
i aplicació el mètode que hagi dissenyat a cada Contenidor.*/

public class iteratores { 
	
	

	public static <T> void iterCollection (Collection<T> c) {
		Iterator<T> ite =c.iterator();
		while(ite.hasNext()) {
			System.out.println(ite.next().toString());
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				 
		ArrayList<Factura>al=new ArrayList<Factura>();
		LinkedList<Factura>ll= new LinkedList<Factura>();
		HashSet <Factura>hs = new HashSet<Factura>();
		LinkedHashSet <Factura>lhs = new LinkedHashSet<Factura>(); 
		TreeSet <Factura>ts = new TreeSet<Factura>();
		
		Factura clientela[] = new Factura[5];
		clientela[0] = new Factura(001,"Juan Alvarez");
		clientela[1] = new Factura(002,"Antonio Sanchez");
		clientela[2] = new Factura(003,"Jordi Roca");
		clientela[4] = new Factura(005,"Luis López");
		clientela[3] = new Factura(004,"Alberto Pérez");
		
		
		// Array List
		System.out.println("ArrayList:  ");
		for (int i = 0; i<clientela.length;i++) {
			al.add(clientela[i]);}
		iterCollection(al);
		
		// LInked List
		System.out.println("\nLinkedList:  ");
		for (int c = 0; c<clientela.length;c++) {
			ll.add(clientela[c]);}
		iterCollection(ll);
		
		//HashSet
		
		System.out.println("\nHashSet:  ");
		for (int c = 0; c<clientela.length;c++) {
			hs.add(clientela[c]);}
		iterCollection(hs);
		
	    System.out.println("\nLikedHashSet:  ");
	    for (int c = 0; c<clientela.length;c++) {
			hs.add(clientela[c]);}
		iterCollection(hs);
	    
	    
	    System.out.println("\nTreeSet:  ");
	    for (int c = 0; c<clientela.length;c++) {
			ts.add(clientela[c]);}
		iterCollection(ts);
	}
	
}