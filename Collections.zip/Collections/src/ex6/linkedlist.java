package ex6;

import java.util.*;

/*Exercici 6. Creu un objecte buit LinkedList<Integer>. 
Utilitzant un iterador ListIterator, afegeixi valors sencers
a la llista inserint-los sempre a la meitat d'aquesta.*/



public class linkedlist {
    public static List<Integer> insertInMiddle(List<Integer> list, Integer num) { 
        int halfLength = list.size()/2;
        ListIterator<Integer> ite = list.listIterator();
        List<Integer> resultList = new LinkedList<Integer>();
        for (int i = 0; i < halfLength; i++) {
            resultList.add(ite.next());
        }
        resultList.add(num);
        while (ite.hasNext()) {
            resultList.add(ite.next());
        }
        return resultList;
    }
    public static void main(String[] args) {
        List<Integer> list = new LinkedList<Integer>();
        int times = 10;
        for (int i = 0; i < times; i++) {
            list = insertInMiddle(list,i);
        }
        System.out.println(list);
    }
}


