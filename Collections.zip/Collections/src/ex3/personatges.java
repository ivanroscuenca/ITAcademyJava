package ex3;

import java.util.*;

public class personatges {
    public static interface Generator<T> {
       public T next();
    }
    public static class FilmGenerator implements Generator<String> {
        private static final String[] FILMNAME={"Michael Corleone", "Fredo Corleone", "Sonny Corleone", "Carmella Corleone", "Don Fannucci",
            "Peter Clemenza", "Luca Brasi", "Rocco Lampone", "Al Neri"};
        private static final int LENGTH = FILMNAME.length;
        private static int count = 0;
        private final int id = ++count;
        private int cursor = 0;
        public String next() {
            if (cursor == LENGTH) {
                cursor =  0;
            }
            return FILMNAME[cursor++];
        }
    }
    public static Generator<String> getFilmGenerator(){
        return new FilmGenerator();
    }
    public static String[] getFilms(String[] array) {
        Generator<String> gen = getFilmGenerator();
        for (int i = 0; i < array.length; i++) {
            array[i] = gen.next();
        }
        return array;
    }
    public static Collection<String> getFilms(Collection<String> c, int filmNum) {
        Generator<String> gen = getFilmGenerator();
        for (int i = 0; i < filmNum; i++) {
            c.add(gen.next());
        }
        return c;
    }

    public static void main(String[] args){
        int size = 10;
        //Matriu
        System.out.println(">>>Array:  ");
        System.out.println(Arrays.toString(getFilms(new String[size])));
        //arraylist
        System.out.println(">>>ArrayList:  ");
        System.out.println(getFilms(new ArrayList(),size));
        //linkedlist
        System.out.println(">>>LinkedList:  ");
        System.out.println(getFilms(new LinkedList(),size));
        //hashset
        System.out.println(">>>HashSet:  ");
        System.out.println(getFilms(new HashSet(),size));
        //linkedhashset
        System.out.println(">>>LinkedHashSet:  ");
        System.out.println(getFilms(new LinkedHashSet(),size));
        //treeset
        System.out.println(">>>TreeSet:  ");
        System.out.println(getFilms(new TreeSet(),size));
    }
}
