package ex8;

import java.util.*;

/*Exercici 8. Empleni un mapa LinkedHashMap amb claus de tipus String i objectes del tipus que prefereixi. 
Extregui les parelles, ordeni-les segons les claus (en ordre alfab�tic) i torni a inserir-les en el mapa.*/

public class ex8 {

	public static class Packing {
		private double weight;
		private String colour;
		public Packing(String colour, double weight) {
			this.colour = colour;
			this.weight = weight;
		}
		public String packingData() {
			
			return "El color de l'embalatge es "+ colour+ " i el seu pes es "+ weight +" kg.";
			
		}	
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		LinkedHashMap<String, Packing> food = new LinkedHashMap<>();
		//Fill in a LinkedHashMap with String keys and objects of the type you prefer.
		food.put("Arros.", new Packing("Blanc",1));
		food.put("Farina.", new Packing("Blanc",1));
		food.put("Sucre.", new Packing("Blau",1));
		food.put("Llet.", new Packing("Blanc",1.5));
		food.put("Ous.", new Packing("Gris",0.5));
		
		Map<String, Packing> aux = new HashMap<>();
		int i = 0;
		String[] keys =new String[food.size()];
		
		for (Map.Entry<String, Packing> entry : food.entrySet()) {
			keys[i++] = entry.getKey();
			aux.put(entry.getKey(),entry.getValue());
			
		}
		//Remove the pairs,
		food.clear();
		// sort them by keys (in alphabetical order)
		Arrays.sort(keys);
	
		//re-insert them on the map
		for(String key : keys) {
		food.put(key, aux.get(key));
		}
		

		for (Map.Entry<String, Packing> entry : food.entrySet()) {
			
			System.out.println("Productes alimentaris: "+ entry.getKey()+" "+ entry.getValue().packingData());
		}
		
	}


	
}
