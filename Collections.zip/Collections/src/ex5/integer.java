package ex5;

import java.util.*;

/*Creu i empleni un objecte List<Integer>. Creu un segon objecte List<Integer> de la mateixa grand�ria que el primer
i utilitzi sengles objectes ListIterator per a llegir els elements de la primera llista i 
inserir-los en la segona en ordre invers (provi d'explorar diverses formes diferents de resoldre aquest problema).*/

public class integer {

	public static void main(String[] args) {
		

		List<Integer> myList = new ArrayList<Integer>();
		
		myList.add(10);
		myList.add(20);
		myList.add(30);
		myList.add(40);
		myList.add(50);
		
	Iterator<Integer> it = myList.iterator(); 
		while (it.hasNext()) {
			System.out.println(it.next()); 
		}
		
		System.out.println("----------------------------------------------------------------------------");
		

		ArrayList<Integer>myList2 = new ArrayList<Integer>(myList);
		
		ListIterator<Integer> Listit = myList2.listIterator(myList2.size());
		
		while(Listit.hasPrevious()) {
			  System.out.println(Listit.previous());
		
	}

	}
	
}
