package ex7;

import java.util.*;

/*Exercici 7. Empleni un HashMap amb parells clau-valor. Imprimeixi els resultats per a mostrar 
l'ordenaci� segons el codi hash. Ordeni les parelles, extregui la clau i introdueixi el resultat en un mapa 
LinkedHashMap. Demostri que es mant� l'ordre d'inserci�.
Repeteixi el punt anterior amb HashSet i amb LinkedHashSet.*/

public class hashMap {
	public static void main(String[] args) {
		HashMapper hm = new HashMapper();
		hm.fillMap();
		hm.remap();
		hm.fillHashSet();
		hm.remapSet();
	}
}

class HashMapper{
	HashMap<Integer, String> map = new HashMap<Integer, String>();
	LinkedHashMap<Integer, String> linkedmap = new LinkedHashMap<Integer, String>();
	HashSet<Integer> set = new HashSet<Integer>();
	LinkedHashSet<Integer> linkedset = new LinkedHashSet<Integer>();
	
	public void fillMap(){
		Random rand = new Random(42);
		int k;
		for (int i=0; i<10; i++){
			k = rand.nextInt(i+20);
			map.put(k, Integer.toString(k));
		}
		System.out.println("Ordenat per HashMap" + map);
	}
	
	public void remap(){
		Set<Integer> keyset = map.keySet();
		Iterator<Integer> it;
		int temp;
		int smallest;
		int iterations = keyset.size(); 
		for (int i = 0; i < iterations; i++) {
			it = keyset.iterator();
			smallest = it.next();
			it = keyset.iterator();
			while(it.hasNext()) {
				temp = it.next();
				if (temp < smallest) smallest = temp;
			}
			linkedmap.put(smallest, map.get(smallest));
			keyset.remove(smallest);
		}
		System.out.println("Ordenat per Linkedmap" + linkedmap);
	}


public void fillHashSet(){
	Random rand = new Random(42);
	int k;
	for (int i=0; i<10; i++){
		k = rand.nextInt(i+20);
		set.add(k);
	}
	System.out.println("Ordenat per HashSet" + set);
}

public void remapSet(){
	Iterator<Integer> it;
	int temp;
	int smallest;
	int iterations = set.size(); 
	for (int i = 0; i < iterations; i++) {
		it = set.iterator();
		smallest = it.next();
		it = set.iterator();
		while(it.hasNext()) {
			temp = it.next();
			if (temp < smallest) smallest = temp;
		}
		linkedset.add(smallest);
		set.remove(smallest);
	}
	System.out.println("Ordenat per LinkedSet" + linkedset);
}
}

