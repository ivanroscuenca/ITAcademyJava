package ItacademyLambdaFase3;

/*Crea  una Functional Interface que conting a un mètode abstracte reverse (),
que retorn e un valor String; en una  altra classe,  injecta a la interfície 
creada mitjançant una lambda el cos de l  mètode, de manera que torne la  mateixa
cadena que rep  com a paràmetre però a l'inrevés. 
Invoca la instància de la  interfície passant-li una cadena i  comprovant el resultat. */

public class fase3 {

	public static void main(String[] args) {
		FunctionalInterface ReverseString = (str)->{
			String res ="";
			for (int i = str.length()-1;i>=0; i--)
			res += str.charAt(i);
			return res;
		};
		
		System.out.println(ReverseString.reverse("Hola"));

	}

}

