package ItacademyLambdaFase3;

public interface FunctionalInterface {
String reverse(String r);
}
