package ItacademyLambda;

import java.util.*;
import java.util.stream.Collectors;

/*Tenint una llista de Strings, escriu un mètode 
que retorne una llista de totes les  cadenes  que 
continguen la lletra ‘o’ i  imprimeix el resultat */

public class main3 {

	public static void main(String[] args) {
		List <String> noms = Arrays.asList("Ana","Oriol", "Oliver", "Joana", "Ava", "Jordi", "Miquel", "Joan", "Xavier");
		System.out.println (" Els noms són: " + noms);

		
		List<String> nomsambo = noms.stream().filter(nom-> nom.contains("O") ||
				nom.contains("o")).collect(Collectors.toList());
		System.out.println (" Els noms que contenen la lletra 'o' són: " + nomsambo);

	}

}
