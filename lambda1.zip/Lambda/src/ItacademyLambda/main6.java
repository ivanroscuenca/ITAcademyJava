package ItacademyLambda;

import java.util.Arrays;
import java.util.List;

/*Has de  fer la mateixa impressió del 
punt  anterior  però fent-ho mitjançant 
method   reference. */

public class main6 {

	public static void main(String[] args) {
		List <String> mesosany = Arrays.asList("Gener","Febrer", "Març", "Abril", "Maig", 
				"Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre");
		
		System.out.println("Impressió amb method reference : ");
		mesosany.forEach(System.out::println);

	}

}
