package ItacademyLambda;

import java.util.*;
/*
Crea una llista amb  els noms dels mesos de l’any. 
Imprimeix tots els  elements de la llista amb  una lambda. */

public class main5 {

	public static void main(String[] args) {
		List <String> mesosany = Arrays.asList("Gener","Febrer", "Març", "Abril", "Maig", 
				"Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre");
		System.out.println(" Impressió sense lambda : " + mesosany);
		
		System.out.print(" Impressió amb lambda : ");
		mesosany.forEach(mes -> System.out.print(mes + ","));

	}

}
