package ItacademyLambda;

import java.util.*;
import java.util.stream.Collectors;

/*Escriu un mètode que retorne una cadena separada per comes basada en una llista d’Integers. 
Cada element  hauria d'anar precedit per la  lletra  "e" si el nombre és parell , i precedit de la 
lletra  "o" si el nombre és im parell. Per exemple, si la llista  d'entrada és (3,44),
la sortida hauria de ser "o3, e44".Imprimeix el  resultat. */

public class main2 {

	public static void main(String[] args) {
		
		List<Integer>numeros= Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		System.out.println("Els números són : " + numeros);
		
		
		List <String> numerosmodificats = numeros.stream().map(numero -> numero %2 ==0?
				("p" + numero) : ("s" + numero)).collect(Collectors.toList());
		System.out.println("Els numeros modificats són parell = p / senar = s : " + numerosmodificats);
		
	}

}
