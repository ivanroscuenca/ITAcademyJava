package ItacademyLambda;

import java.util.*;
import java.util.stream.Collectors;

/*Tenint una llista de cadenes de noms propis,  escriu un mètode que retorn e una llista de totes les cadenes
que  comencen amb la lletra 'a' (mayuscula ) i  tenen exactament 3  lletres. Imprimeix el resultat . */

public class main {

	public static void main(String[] args) {
		List<String> noms = Arrays.asList("Ana", "Joana", "Ava", "Jordi", "Miquel", "Joan", "Xavier");
		System.out.println (" Els noms són: " + noms);
		
		List<String> nomsambA3 = noms.stream().filter(nom-> nom.startsWith("A") &&
				nom.length() == 3).collect(Collectors.toList());
		System.out.println (" Els noms de 3 lletres i comencen amb A majúscula són: " + nomsambA3);
	}
}
