package ItacademyLambda;

import java.util.*;
import java.util.stream.Collectors;

/*Has de fer el mateix que en el punt anterior,
però retornant una llista que  incloga els elements amb 
més de 5 lletres. Imprimeix  el resultat. */

public class main4 {

	public static void main(String[] args) {
		List <String> noms = Arrays.asList("Ana","Oriol", "Oliver", "Joana", "Ava", "Jordi", "Miquel", "Joan", "Xavier");
		System.out.println (" Els noms són: " + noms);

		
		List<String> nomsamboi5ll = noms.stream().filter(nom-> nom.contains("O") && nom.length()>5 ||
				nom.contains("o") && nom.length()>5).collect(Collectors.toList());
		System.out.println (" Els noms que contenen la lletra 'o' i tenen més de 5 lletres són: " + nomsamboi5ll);

	}

}
