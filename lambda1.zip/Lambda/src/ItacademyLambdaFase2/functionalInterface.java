package ItacademyLambdaFase2;

public interface functionalInterface {
double getPiValue();
}
