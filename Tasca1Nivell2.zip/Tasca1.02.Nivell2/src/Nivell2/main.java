package Nivell2;

/*Repeteixi l'exercici anterior, per� dins de la cl�usula catch, 
 * emboliqui l'excepci� 'g()' dins d'una RuntimeException. 
*/

public class main {
	
public static void g(){
			
		throw new  IndexOutOfBoundsException("Nova Excepci�");
	}
	
	public static void f() {
		
		try{g();
		}catch (IndexOutOfBoundsException e){
			throw new NumberFormatException();}
		}

	public static void main(String[] args) {
		try{g();
		}catch (RuntimeException e){
			System.out.println("Nova captura ");
		}
	}
}

