package Nivell1;

/*Creu una classe amb dos m�todes, 'f()' i 'g()'. 
 * En 'g()', generi una excepci� d'un nou tipus. 
 * En 'f()' invoqui a 'g()', capturi la seva excepci� i,
 *  en la cl�usula catch, generi una excepci� diferent (d'un segon tipus, 
 *  tamb� nou). Comprovi el codi en 'main()'. 
*/

public class main {
	
public static void g(){
		
		
		throw new  IndexOutOfBoundsException("Nova Excepci�");
	}
	
	public static void f() {
		
		try{g();
		}catch (IndexOutOfBoundsException e){
			throw new NumberFormatException();}
		}


	public static void main(String[] args) {
		g();

	}

}
